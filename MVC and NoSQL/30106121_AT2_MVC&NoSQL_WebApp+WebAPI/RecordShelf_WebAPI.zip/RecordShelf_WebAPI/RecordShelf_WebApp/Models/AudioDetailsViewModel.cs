﻿namespace RecordShelf_WebApp.Models
{
    public class AudioDetailsViewModel
    {
        public AudioViewModel Audio { get; set; } = null!;

        public AnalyticsViewModel Analytics { get; set; } = null!;
    }
}
